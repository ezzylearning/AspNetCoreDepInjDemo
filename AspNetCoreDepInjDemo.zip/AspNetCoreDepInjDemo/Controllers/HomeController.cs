﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AspNetCoreDepInjDemo.Models;
using AspNetCoreDepInjDemo.Services;

namespace AspNetCoreDepInjDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductService _productService;

        public HomeController(IProductService productService)
        {
            _productService = productService;
        }

        public IActionResult Index()
        {
            var products = _productService.GetProducts();
            return View(products);
        }

        //public IActionResult Index([FromServices] IProductService productService)
        //{
        //    var products = productService.GetProducts();
        //    return View(products);
        //}
    }
}
