﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetCoreDepInjDemo.Models;

namespace AspNetCoreDepInjDemo.Services
{
    public interface IProductService
    {
        List<Product> GetProducts();
    }
}
